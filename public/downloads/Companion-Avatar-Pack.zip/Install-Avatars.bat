@echo off
chcp 65001 >nul
title Desktop Companion - Community Avatar Pack Installer
color 0B
echo ======================================================================
echo    Desktop Companion - Free Community Avatar Pack (8 Mascots)
echo ======================================================================
echo.
echo Installing new animated avatars into your existing Desktop Companion...
echo NOTE: Your personal username, water goals, and schedules will remain 100%% INTACT!
echo.

set "TARGET_DIR=%LOCALAPPDATA%\Programs\Desktop Companion\assets\custom_avatars"
if not exist "%LOCALAPPDATA%\Programs\Desktop Companion" (
    if exist "..\assets\custom_avatars" (
        set "TARGET_DIR=..\assets\custom_avatars"
    ) else if exist "assets\custom_avatars" (
        set "TARGET_DIR=assets\custom_avatars"
    )
)

if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

echo Copying animated avatars to:
echo "%TARGET_DIR%"
echo.
xcopy /Y /Q "avatars\*.gif" "%TARGET_DIR%\" >nul

if %ERRORLEVEL% EQU 0 (
    echo ======================================================================
    echo   SUCCESS! 8 New Avatars Have Been Added to Your Companion!
    echo ======================================================================
    echo.
    echo Newly installed characters:
    echo   - Shiba Inu Puppy (shiba_inu.gif)
    echo   - Baby Dragon (baby_dragon.gif)
    echo   - Bouncing Panda (bouncing_panda.gif)
    echo   - Waddling Penguin (waddling_penguin.gif)
    echo   - Chill Capybara with Orange (chill_capybara.gif)
    echo   - Pink Smiling Axolotl (pink_axolotl.gif)
    echo   - Twinkling Golden Star (golden_star.gif)
    echo   - Magic Hydration Potion (magic_potion.gif)
    echo.
    echo HOW TO USE IN APP:
    echo   1. Right-click the blue 💧 Water Droplet in your taskbar tray.
    echo   2. Go to "Avatars & Skins" - your new pets will be listed under Custom!
    echo   3. Or turn on "Dynamic" and the companion will cycle through them!
    echo.
) else (
    echo [ERROR] Could not automatically locate Desktop Companion folder.
    echo Please copy the files in the "avatars" folder manually into:
    echo "%LOCALAPPDATA%\Programs\Desktop Companion\assets\custom_avatars"
)
echo.
pause
