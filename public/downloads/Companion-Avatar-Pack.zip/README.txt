COMMUNITY AVATAR PACK (8 NEW MASCOTS)
=====================================
For Desktop Companion (Windows, Mac, Android, iOS)

INCLUDED PETS:
1. shiba_inu.gif       - Energetic golden Shiba Inu with wagging tail
2. baby_dragon.gif     - Tiny emerald dragon with flapping wings
3. bouncing_panda.gif  - Chubby panda that bounces with delight
4. waddling_penguin.gif- Antarctic tuxedo penguin
5. chill_capybara.gif  - Super chill capybara balancing an orange
6. pink_axolotl.gif    - Smiling aquatic axolotl with water bubbles
7. golden_star.gif     - Retro glowing 8-bit star
8. magic_potion.gif    - Animated bubbling cyan hydration potion

HOW TO INSTALL ON WINDOWS:
Method 1 (Automatic 1-Click):
  Simply double-click 'Install-Avatars.bat'. It will automatically copy all
  avatars to your existing installation without modifying your settings!

Method 2 (Manual Drag-and-Drop):
  1. Open Desktop Companion.
  2. Right-click the 💧 tray icon > Settings... > Avatars tab.
  3. Click 'Open Avatar Folder'.
  4. Drag and drop all .gif files from the 'avatars' folder into it.
  5. Done! Your new avatars appear immediately under 'Avatars & Skins'.

NOTE:
This expansion pack preserves your name, cups tracker, schedule, and quiet
hours. No reinstallation needed!
